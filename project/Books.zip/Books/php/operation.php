<link rel="stylesheet" type="text/css" href="style.css">
<?php 

	require_once("db.php");
	require_once("component.php");

// create button click
	if (isset($_POST['create'])) {
		$bookname = $_POST['book_name'];
		$bookpublisher = $_POST['book_publisher'];
		$bookprice = $_POST['book_price'];
if ($bookname && $bookpublisher && $bookprice) {
		$sql = "INSERT INTO `books`(`id`, `book_name`, `book_publisher`, `book_price`) VALUES ('','$bookname','$bookpublisher','$bookprice')";
		$result = mysqli_query($conn, $sql);
if ($result) {
	TextNode("success","Thêm mới sách thành công!");
}else{
	TextNode("error","Thêm mới sách thất bại!");
}
}else{
	TextNode("danger","Nhập đầy đủ thông tin trước khi thêm mới sách!");
}
}

function TextNode($classname,$smg)
{
	$element = "<h6 class='$classname text-center'>$smg</h6>";
	echo $element;
}

//update Data
if(isset($_POST['update'])){
	$bookid = $_POST['book_id'];
	$bookname = $_POST['book_name'];
	$bookpublisher = $_POST['book_publisher'];
	$bookprice = $_POST['book_price'];

	if ($bookname && $bookpublisher && $bookprice) {
		$sql = "
			UPDATE `books` SET `book_name`='$bookname',`book_publisher`='$bookpublisher',`book_price`='$bookprice' WHERE id='$bookid' 
		";
		$result = mysqli_query($conn, $sql);
		if ($result) {
			TextNode("success","Cập nhật thông tin thành công!");
		}else{
			TextNode("error","Cập thật thông tin thất bại!");
		}
	}else{
		TextNode("danger","Cảnh báo, đã có lỗi xảy ra!");
	}
}


// delete Data
if (isset($_POST['delete'])) {
	$bookid = (int)$_POST['book_id'];

	$sql = "DELETE FROM books WHERE id=$bookid";
	$result = mysqli_query($conn,$sql);

	if ($bookid > 0) {
		TextNode("success","Xóa thành công!");
	}else{
		TextNode("error","Thất bại. Vui lòng kiểm tra lại!");
	}
}