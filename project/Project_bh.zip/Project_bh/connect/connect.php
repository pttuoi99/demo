<?php 
	$conn = mysqli_connect("localhost", "root","","project_bh") or die('kết nối không thành công!');
			mysqli_set_charset($conn,"utf8");

 ?>