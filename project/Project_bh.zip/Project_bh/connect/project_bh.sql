-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th5 18, 2019 lúc 04:28 PM
-- Phiên bản máy phục vụ: 10.1.34-MariaDB
-- Phiên bản PHP: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `project_bh`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` int(11) NOT NULL,
  `password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `hoten` varchar(100) NOT NULL,
  `noidung` text NOT NULL,
  `ngay` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customer`
--

CREATE TABLE `customer` (
  `idkh` int(11) NOT NULL,
  `hoten` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) NOT NULL,
  `sdt` int(10) NOT NULL,
  `diachi` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tp` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `customer`
--

INSERT INTO `customer` (`idkh`, `hoten`, `email`, `sdt`, `diachi`, `tp`, `password`) VALUES
(1, 'Phạm Thanh Tươi', 'phamthanhtuoi0@gmail.com', 919918817, 'Nam kì khởi nghĩa, Hòa Quý, Ngũ Hành Sơn', 'Đà Nẵng', '18061999'),
(2, 'phạm thanh tươi', 'phamthanhtuoi0@gmail.com', 975323376, 'Thôn Trà đình 2, Quế phú, Quế sơn', 'Quảng Nam', '12345678');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `processed`
--

CREATE TABLE `processed` (
  `id` int(11) NOT NULL,
  `idkh` int(11) NOT NULL,
  `masp` varchar(50) NOT NULL,
  `soluong` int(11) NOT NULL,
  `thanhtien` int(11) NOT NULL,
  `ngaymua` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `tensp` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dongia` int(11) NOT NULL,
  `mota` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) NOT NULL,
  `ngaycn` date NOT NULL,
  `sl` int(11) NOT NULL,
  `loaihang` varchar(50) NOT NULL,
  `search` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `danhmuc` varchar(255) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `hangsx` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`id`, `tensp`, `dongia`, `mota`, `img`, `ngaycn`, `sl`, `loaihang`, `search`, `danhmuc`, `hangsx`, `size`) VALUES
(1, '\r\nBalo chiến thuật 3D', 260000, '\r\nBalo chiến thuật 3D', 'balo1.jpg', '2019-01-01', 95, 'balo', '0', 'Balo Túi Chéo', '', ''),
(2, 'Balo chiến thuật 3P', 230000, 'Balo chiến thuật 3P', 'balo2.jpg', '2018-12-25', 95, 'balo', '0', 'Balo Túi Chéo', '', ''),
(3, 'Balo chiến thuật 7D', 400000, 'Balo chiến thuật 7D', 'balo3.jpg', '2018-12-05', 99, 'balo', '0', 'Balo Túi Chéo', '', ''),
(4, 'Balo The Northe Face 55l', 300000, 'Balo The Northe Face 55l', 'balo4.jpg', '2019-02-21', 100, 'balo', '0', 'Balo Túi Chéo', '', ''),
(5, 'Túi đeo chéo Army\r\n', 199000, 'Túi đeo chéo Army\r\n', 'balo5.jpg', '2019-01-21', 100, 'balo', '0', 'Balo Túi Chéo', '', ''),
(6, 'Túi đeo điện thoại', 110000, 'Túi đeo điện thoại', 'balo6.jpg', '2018-11-11', 100, 'balo', '0', 'Balo Túi Chéo', '', ''),
(7, 'Túi đeo hông có bình nước\r\n', 150000, 'Túi đeo hông có bình nước\r\n', 'balo7.jpg', '2019-03-01', 100, 'balo', '0', 'Balo Túi Chéo', '', ''),
(8, 'Combo 3 món 119k', 119000, 'Combo 3 món 119k', 'combo1.jpg', '2019-04-01', 95, 'combo', '0', 'Combo Phượt', '', ''),
(9, 'Combo 4 món 210k', 210000, 'Combo 4 món 210k', 'combo2.jpg', '2018-10-25', 100, 'combo', '0', 'Combo Phượt', '', ''),
(10, 'Combo 4 món 379k', 379000, 'Combo 4 món 379k', 'combo3.jpg', '2018-10-05', 100, 'combo', '0', 'Combo Phượt', '', ''),
(11, 'Combo 5 món 290k', 290000, 'Combo 5 món 290k', 'combo4.jpg', '2019-03-31', 99, 'combo', '0', 'Combo Phượt', '', ''),
(12, 'Combo 5 món 389k', 389000, 'Combo 5 món 389k', 'combo5.jpg', '2019-01-10', 100, 'combo', '0', 'Combo Phượt', '', ''),
(13, 'Combo chất 4 món', 750000, 'Combo chất 4 món', 'combo6.jpg', '2018-11-30', 100, 'combo', '0', 'Combo Phượt', '', ''),
(14, 'Combo Chất Full người', 1700000, 'Combo Chất Full người', 'combo7.jpg', '2019-03-10', 100, 'combo', '0', 'Combo Phượt', '', ''),
(15, 'Áo giáp lưới Probiker', 350000, 'Áo giáp lưới Probiker', 'giap1.jpg', '2019-02-25', 90, 'giap', '0', 'Giáp Bảo Hộ', '', ''),
(16, 'Giáp chân tay Inox', 299000, 'Giáp chân tay Inox', 'giap2.jpg', '2019-03-11', 98, 'giap', '0', 'Giáp Bảo Hộ', '', ''),
(17, 'Giáp nhựa fox', 99000, 'Giáp nhựa fox', 'giap3.png', '2019-01-25', 100, 'giap', '0', 'Giáp Bảo Hộ', '', ''),
(18, 'Giáp chân tay Phản quang', 399000, 'Giáp chân tay Phản quang', 'giap4.png', '2019-01-25', 100, 'giap', '0', 'Giáp Bảo Hộ', '', ''),
(19, 'Giày Swat cao cổ', 390000, 'Giày lính swat  là mẫu giày được thiết kế riêng cho lực lượng SWAT (Special Weapons And Tatics) của Mĩ. So với các mẫu giày thường dùng đi phượt,đi du lịch… dòng sản phẩm này có một số điểm vượt trội.\r\n\r\n', 'giay1.jpg', '2018-08-25', 95, 'giay', '0', 'Giày Phượt', '', 'Giày có các size từ 39-44 với 2 màu vàng cát và đen'),
(20, 'Giày Swat cổ thấp', 499000, 'Giày SWAT Original cổ thấp Giày SWAT- original là mẫu giày được thiết kế riêng cho lực lượng SWAT (Special Weapons And Tatics) của Mĩ.', 'giay2.png', '2019-01-25', 96, 'giay', '0', 'Giày Phượt', '', 'MÀU SẮC : Đen, Vàng Cát SIZE : 39, 40, 41, 42, 43'),
(21, 'Giày TNF cổ cao', 599000, 'Giày Trekking leo núi là loại giày được thiết kế riêng cho các hoạt động leo núi, trekking, đi bộ đường dài. Thiết kế năng động, chắc chắn bằng các công nghệ hiện đại đảm bảo chất lượng, độ bền cao nhất. Giày được thiết kế cổ cao trên mắt cá chân, ôm bàn chân cho cảm giác thoải mái nhất khi di chuyển hay phải leo ở những nơi có địa hình gồ ghề, hiểm trở. Giày được sản xuất trên công nghệ Gore-tex nên rất bền, có khả năng chống nước nhẹ, chống mưa nhỏ và vẫn rất thông thoáng khi đeo. Đế giày Vibram có độ bám cao, chống trơn trượt khi di chuyển.', 'giay3.jpg', '2018-10-25', 100, 'giay', '0', 'Giày Phượt', '', 'Giày có các size từ 39-44 với 2 màu vàng cát và đen'),
(22, '\r\nGiày TNF cổ thấp', 590000, '', 'giay4.jpg', '2018-11-05', 100, 'giay', '0', 'Giày Phượt', '', ''),
(23, 'Găng Black Hawk ngón cụt', 90000, 'Găng Black Hawk ngón cụt', 'gt1.jpg', '2019-01-02', 96, 'gangtay', '0', 'Găng Tay', '', ''),
(24, 'Găng tay da giữ nhiệt cảm ứng điện thoại', 170000, 'Găng tay da giữ nhiệt cảm ứng điện thoại', 'gt10.jpg', '2019-01-01', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(25, 'Găng tay Probiker ngón dài', 120000, 'Găng tay Probiker ngón dài', 'gt11.jpg', '2019-03-05', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(26, '\r\nGăng tay Probiker ngón cụt', 90000, '\r\nGăng tay Probiker ngón cụt', 'gt12.jpg', '2019-01-10', 99, 'gangtay', '0', 'Găng Tay', '', ''),
(27, 'Găng Black Hawk ngón dài', 150000, 'Găng Black Hawk ngón dài', 'gt2.png\r\n', '2019-03-25', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(28, 'Găng Mechanix ngón cụt', 99000, 'Găng Mechanix ngón cụt', 'gt3.jpg', '2019-02-25', 99, 'gangtay', '0', 'Găng Tay', '', ''),
(29, 'Găng Oakley ngón cụt', 90000, 'Găng Oakley ngón cụt', 'gt4.jpg', '2018-12-25', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(30, 'Găng Oakley ngón dài', 120000, 'Găng Oakley ngón dài', 'gt5.png', '2019-01-15', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(31, 'Găng tay 511 ngón cụt', 40000, 'Găng tay 511 ngón cụt', 'gt6.jpg', '2019-02-03', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(32, 'Găng tay 511 ngón dài', 60000, 'Găng tay 511 ngón dài', 'gt7.jpg', '2019-03-02', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(33, '\r\nGăng tay chống nước Xueyu', 250000, '\r\nGăng tay chống nước Xueyu', 'gt8.jpg', '2018-11-15', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(34, 'Găng tay TNF chống nước', 150000, 'Găng tay TNF chống nước', 'gt9.jpg', '2019-03-27', 100, 'gangtay', '0', 'Găng Tay', '', ''),
(35, 'Kính gắn mũ 3/4 thường', 150000, 'Kính gắn mũ 3/4 thường', 'kinh1.jpg', '2019-03-15', 100, 'kinh', '0', 'Kính Phượt', '', ''),
(36, 'Kính 5 mắt Oakley', 199000, 'Kính 5 mắt Oakley', 'kinh2.jpg', '2019-02-15', 100, 'kinh', '0', 'Kính Phượt', '', ''),
(37, 'Kính Oulaiou đi đêm', 60000, 'Kính Oulaiou đi đêm', 'kinh3.jpg', '2018-12-15', 100, 'kinh', '0', 'Kính Phượt', '', ''),
(38, 'Mặt nạ Beon gẵn mũ 3/4', 199000, 'Mặt nạ Beon gẵn mũ 3/4', 'kinh4.jpg', '2019-01-30', 100, 'kinh', '0', 'Kính Phượt', '', ''),
(39, 'Kính gắn mũ Bubble', 170000, 'Kính gắn mũ Bubble', 'kinh5.png\r\n', '2018-10-30', 100, 'kinh', '0', 'Kính Phượt', '', ''),
(40, 'Mũ AGU fullface tem Rùa', 399000, 'Mũ AGU fullface tem Rùa', 'mbh1.jpg', '2018-09-12', 79, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(41, 'Mũ bảo hiểm 3/4 + kính uv', 230000, 'Mũ bảo hiểm 3/4 + kính uv', 'mbh10.jpg', '2019-02-08', 94, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(42, 'Mũ bảo hiểm 1/2 tem rùa', 120000, 'Mũ bảo hiểm 1/2 tem rùa', 'mbh11.jpg', '2019-03-09', 96, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(43, 'Mũ bảo hiểm Royal M139 tem vàng', 590000, 'Mũ bảo hiểm Royal M139 tem vàng', 'mbh12.jpg', '2019-01-21', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(44, 'Mũ bảo hiểm Asia M115', 390000, 'Mũ bảo hiểm Asia M115', 'mbh13.png', '2019-03-03', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(45, 'Mũ bảo hiểm 3/4 Bopa', 260000, 'Mũ bảo hiểm 3/4 Bopa', 'mbh14.jpg', '2019-03-20', 98, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(46, 'Mũ bảo hiểm GXT 3/4 2 kính', 430000, 'Mũ bảo hiểm GXT 3/4 2 kính', 'mbh15.jpg', '2018-07-16', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(47, 'Mũ bảo hiểm Royal tem trắng', 600000, 'Mũ bảo hiểm Royal tem trắng', 'mbh2.jpg', '2018-11-07', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(48, 'Mũ bảo hiểm Royal M136', 450000, 'Mũ bảo hiểm Royal M136', 'mbh3.jpg', '2019-03-20', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(49, 'Mũ bảo hiểm Jiekai 316 tem mặt trời', 800000, 'Mũ bảo hiểm Jiekai 316 tem mặt trời', 'mbh4.jpg', '2018-12-01', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(50, 'Mũ bảo hiểm Royal M136', 450000, 'Mũ bảo hiểm Royal M136', 'mbh5.jpg', '2019-03-05', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(51, 'Mũ Bảo Hiểm Yohe 978 SRT Cam phản quang', 1300000, 'Mũ Bảo Hiểm Yohe 978 SRT Cam phản quang', 'mbh6.jpg', '2019-02-13', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(52, 'Mũ bảo hiểm GXT 358 Tucan', 650000, 'Mũ bảo hiểm GXT 358 Tucan', 'mbh7.jpg', '2019-02-28', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(53, 'Mũ bảo hiểm GXT 358 đen', 650000, 'Mũ bảo hiểm GXT 358 đen', 'mbh8.jpg', '2019-01-05', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(54, 'Mũ bảo hiểm gxt 2017 đen xanh', 890000, 'Mũ bảo hiểm gxt 2017 đen xanh', 'mbh9.jpg', '2019-03-24', 100, 'mubaohiem', '0', 'Mũ Các Loại', '', ''),
(55, 'Áo cờ Việt Nam', 50000, 'Áo cờ Việt Nam', 'phukien1.jpg', '2019-03-30', 93, 'phukien', '0', 'Phụ Kiện', '', ''),
(56, 'Lều 4 người 2 lớp', 490000, 'Lều 4 người 2 lớp', 'phukien10.jpeg', '2019-01-30', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(57, '\r\nMóc khóa dao đa năng', 60000, '\r\nMóc khóa dao đa năng', 'phukien11.jpg', '2019-02-28', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(58, 'Mũ lưỡi trai Swat', 120000, 'Mũ lưỡi trai Swat', 'phukien12.jpg', '2019-01-30', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(59, '\r\nTúi chống nước điện thoại', 35000, '\r\nTúi chống nước điện thoại', 'phukien13.jpg', '2018-11-30', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(60, '\r\nTúi ngủ đơn', 250000, '\r\nTúi ngủ đơn', 'phukien14.jpg', '2019-01-30', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(61, 'Áo dây phản quang co dãn', 70000, 'Áo dây phản quang co dãn', 'phukien2.png', '2019-01-30', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(62, 'Áo gió The North Face 2 lớp', 280000, 'Áo gió The North Face 2 lớp', 'phukien3.jpg', '2019-01-10', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(63, 'Áo lưới phản quang', 25000, 'Áo lưới phản quang', 'phukien4.jpg', '2018-03-30', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(64, 'Áo mưa bộ', 180000, 'Áo mưa bộ', 'phukien5.jpg', '2018-09-30', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(65, 'Bộ mở vít đa năng', 50000, 'Bộ mở vít đa năng', 'phukien6.jpg', '2019-03-30', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(66, 'Bọc balo chống nước', 40000, 'Bọc balo chống nước', 'phukien7.jpg', '2018-09-15', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(67, 'Đèn pin đi rừng', 150000, '\r\nĐèn pin đi rừng', 'phukien8.jpg', '2018-12-01', 100, 'phukien', '0', 'Phụ Kiện', '', ''),
(68, 'Camera hành trình Eken H9R', 1190000, 'Camera hành trình Eken H9R', 'phukien9.jpg', '2018-12-30', 100, 'phukien', '0', 'Phụ Kiện', '', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sold`
--

CREATE TABLE `sold` (
  `stt` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `idkh` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  `thanhtien` int(11) NOT NULL,
  `ngaymua` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `sold`
--

INSERT INTO `sold` (`stt`, `id`, `idkh`, `soluong`, `thanhtien`, `ngaymua`, `img`) VALUES
(1, 42, 975323376, 1, 120000, '2019-05-13 07:09:35', 'mbh11.jpg'),
(10, 41, 919918817, 1, 230000, '2019-05-13 09:31:36', 'mbh10.jpg'),
(12, 8, 975323376, 2, 238000, '2019-05-14 02:00:04', 'combo1.jpg'),
(13, 26, 919918817, 1, 90000, '2019-05-14 07:49:38', 'gt12.jpg');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hoten` (`hoten`);

--
-- Chỉ mục cho bảng `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`idkh`),
  ADD KEY `sdt` (`sdt`),
  ADD KEY `hoten` (`hoten`);

--
-- Chỉ mục cho bảng `processed`
--
ALTER TABLE `processed`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idkh` (`idkh`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `img` (`img`);

--
-- Chỉ mục cho bảng `sold`
--
ALTER TABLE `sold`
  ADD PRIMARY KEY (`stt`),
  ADD KEY `id` (`id`),
  ADD KEY `idkh` (`idkh`),
  ADD KEY `anh` (`img`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `customer`
--
ALTER TABLE `customer`
  MODIFY `idkh` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `processed`
--
ALTER TABLE `processed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT cho bảng `sold`
--
ALTER TABLE `sold`
  MODIFY `stt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `processed`
--
ALTER TABLE `processed`
  ADD CONSTRAINT `processed_ibfk_1` FOREIGN KEY (`id`) REFERENCES `sold` (`id`);

--
-- Các ràng buộc cho bảng `sold`
--
ALTER TABLE `sold`
  ADD CONSTRAINT `sold_ibfk_2` FOREIGN KEY (`idkh`) REFERENCES `customer` (`sdt`),
  ADD CONSTRAINT `sold_ibfk_3` FOREIGN KEY (`id`) REFERENCES `product` (`id`),
  ADD CONSTRAINT `sold_ibfk_4` FOREIGN KEY (`img`) REFERENCES `product` (`img`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
