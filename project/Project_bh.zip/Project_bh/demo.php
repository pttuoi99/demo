<?php 
	include('connect/connect.php');
	session_start();
	if (isset($_SESSION['login'])) {
		$sql = "SELECT * FROM customer WHERE sdt=".$_SESSION['login'];
		$data=mysqli_query($conn, $sql);
		$row=mysqli_fetch_array($data);
		$demo = $row['hoten'];
	}
 ?>
 <?php 
 echo "$demo";
  ?>