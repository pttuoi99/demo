<?php 
	$conn = mysqli_connect("localhost", "root", "", "project_bh");
	if ($conn) {
		if (isset($_POST['submit'])) {
			$filename = $_FILES['upload']['name'];
			$filetmpname = $_FILES['upload']['tmp_name'];
			$folder = 'image/';
			$ten = $_POST['ten'];
			move_uploaded_file($filetmpname, $folder.$filename);
		$sql = "INSERT INTO `image` (`ID`,`image`) VALUES ('$ten','$filename')";
		$query = mysqli_query($conn, $sql);
		if ($query) {
			echo "upload image";
		}else{
			echo "abc";
		}
	}
}
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title>upload image</title>
 	<link rel="stylesheet" href="">
 </head>
 <body>
 	<form action="up_image.php" method="POST" enctype="multipart/form-data">
 		<input type="text" name="ten">
 		<input type="file" name="upload">
 		<input type="submit" name="submit" value="upload">
 	</form>
 </body>
 </html>