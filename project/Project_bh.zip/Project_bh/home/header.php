<!DOCTYPE html>
<html>
<head>
	<?php include('connect/connect.php') ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Phượt Bụi</title>
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
</head>
<body>
	<div class="navbar-fix fixed-top menutop" >
		<div class="container-fluid clearfix" style="background-color: white; padding-top: 10px; margin-bottom: -10px;">
			<div class="row">
				<div class="col-1 col-md-2 ">
					<div class="logo">
						<a class="navbar-brand" href="function/introduce.php">
							<img src="..\Project_bh/images/logo.jpg" alt="logo" style="width:150px; height: 40px;">
						</a>
					</div>
				</div>
				
				<div style="margin: 0 auto;margin-top: -18px;  margin-bottom: 5px;" class="col-5 col-md-4 ">
					<form method="GET">
						<input type="text" name="tukhoa" class="search form-control" placeholder="danh mục sản phẩm, tên sản phẩm...">

					</form>
				</div>

				<?php 
				session_start();
				if (isset($_SESSION['cart'])) { 
					$count = count($_SESSION['cart']); ?>


					<div class="col-2 col-md-2">
						<div class="cart" >
							<a class="btn btn-success btn-sm ml-1" href="function/cart.php"><i style="font-size: 200% " class="fas fa-cart-plus"></i><span class="badge badge-light"><?php echo "$count" ?></span><!-- <img src="../images/cart.png" alt="logo" style="width:70px; height: 40px; float: right;"> --></a>
						</div>
					</div>
				<?php }else{
					
					$_SESSION['cart'] = array();
				} ?>

			</div>
		</div>


		<div class="topnav" id="myTopnav">
			<div class="navbar-header">
				<a href="#" class="active">Trang Chủ</a>
			</div>
			<a href="function/all_product.php">Tất Cả</a>
			<a href="function/catalog.php?loaihang=mubaohiem">Mũ Các Loại</a>
			<a href="function/catalog.php?loaihang=gangtay">Găng Tay</a>
			<a href="function/catalog.php?loaihang=giay">Giày Phượt</a>
			<a href="function/catalog.php?loaihang=giap">Giáp Bảo Hộ</a>
			<a href="function/catalog.php?loaihang=balo">Balo</a>
			<a href="function/catalog.php?loaihang=phukien">Phụ Kiện</a>
			<a href="function/catalog.php?loaihang=combo">Combo Phượt</a>
			<a href="function/info.php">Thông Tin</a>
			
				
				<?php
				@session_start();
				if (isset($_SESSION['login'])) {
					echo "<a href='login/ttkh.php'><i style='font-size: 150%; float: right;' class='fas fa-user-circle fa-fw'></i></a>";
				}else{
					echo "<a style='float: right;' href='login/login.php'>Login</a>";
				}
				?>
			
			

			<a href="javascript:void(0);" style="font-size:17px;" class="icon" onclick="myFunction()">&#9776;</a>
		</div>
		<script>
			function myFunction() {
				var x = document.getElementById("myTopnav");
				if (x.className === "topnav") {
					x.className += " responsive";
				} else {
					x.className = "topnav";
				}
			}
		</script>
	</div>
</body>
</html>