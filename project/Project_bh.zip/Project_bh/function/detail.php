<div style="background: #f8f8f8">

	<!-- css tap -->
	<style>
		body {font-family: Arial;}

		/* Style the tab */
		.tab {
			overflow: hidden;
			border: 1px solid #ccc;
			background-color: #f1f1f1;
		}

		/* Style the buttons inside the tab */
		.tab button {
			background-color: inherit;
			float: left;
			border: none;
			outline: none;
			cursor: pointer;
			padding: 14px 16px;
			transition: 0.3s;
			font-size: 17px;
		}

		/* Change background color of buttons on hover */
		.tab button:hover {
			background-color: #ddd;
		}

		/* Create an active/current tablink class */
		.tab button.active {
			background-color: #736262;
		}

		/* Style the tab content */
		.tabcontent {
			display: none;
			padding: 6px 12px;
			border: 1px solid #ccc;
			border-top: none;
		}
	</style>


	<?php 
	include('../connect/connect.php');
	$id=$_GET["id"];
	$sql = "SELECT * FROM product where id=$id";
	$result=mysqli_query($conn, $sql);
	$row=mysqli_fetch_array($result);
	?>	
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/style1.css">


	<?php include("function/header.php"); ?>
	<br>

	<div class="container" style="padding-top: 30px;">
		<div class="row">
			<div class="col-sm-6" style="padding-top: 100px;">
				<img src="../image/<?php echo $row['img']; ?>" width="95%" height="500px;">
			</div>
			<div class="col-sm-6" style="padding-top: 100px;">
				<div >
					<h3><?php echo $row['tensp']; ?></h3>
					<hr class="h1">
					<?php 
					$sl = $row['sl'];
					if ($sl == 0) {
						echo "<p style='color: red;'>Sản phẩm đã hết hàng.</p>";
					}
					?>
					<h5 style="color: red"><?php echo number_format($row['dongia']).'₫'; ?></h5>

					<li class="text-muted">Hàng hiệu chất lượng, phong cách thời trang cá tính</li>
					<li class="text-muted">Ship COD toàn quốc</li>
					<li class="text-muted">Chat Facebook hoặc add Zalo 0975323376 để được tư vấn cụ thể màu sắc,size sản phẩm</li>
					<li class="text-muted">Mở cửa 8h30 – 22h tất cả các ngày trong tuần</li>
					<li class="text-muted">Cơ sở chính: Nam kì khởi nghĩa, Hòa Quý, Ngũ Hành Sơn, Đà Nẵng – 0975.323.376</li><br>

					<?php echo "<a href='cart.php?themgiohang=$row[id]'><button type='button' class='btn btn-primary'>THÊM VÀO GIỎ HÀNG</button></a>"; ?><br><br>
					<hr class="h1">
					<p>Danh mục: <?php echo "<a href='catalog.php?tukhoa=$row[danhmuc]'>$row[danhmuc]</button></a>"; ?></p>
					<hr class="h1"><br>
				</div>
			</div>
		</div><br>
		<hr class="h1">
		


		<!-- demo tap -->

		<div class="tab">
			<button class="tablinks" onclick="openCity(event, 'mota')" id="defaultOpen">Mô Tả</button>
			<button class="tablinks" onclick="openCity(event, 'cmt')">Bình Luận</button>
		</div>

		<div id="mota" class="tabcontent">
			<div class="" style="width: 650px;"><br>
				<ul >
					<li class="li5 text-muted"><?php echo $row['tensp']; ?></li>
					<li class="li5 text-muted"><?php echo $row['mota']; ?></li>
					<li class="li5 text-muted"><?php echo $row['size']; ?></li>
				</ul>
			</div>
		</div>

		<div id="cmt" class="tabcontent"><br>
			<p align="center">Không có bình luận.</p> 
		</div>

		<script>
			function openCity(evt, cityName) {
				var i, tabcontent, tablinks;
				tabcontent = document.getElementsByClassName("tabcontent");
				for (i = 0; i < tabcontent.length; i++) {
					tabcontent[i].style.display = "none";
				}
				tablinks = document.getElementsByClassName("tablinks");
				for (i = 0; i < tablinks.length; i++) {
					tablinks[i].className = tablinks[i].className.replace(" active", "");
				}
				document.getElementById(cityName).style.display = "block";
				evt.currentTarget.className += " active";
			}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<hr class="h1">
<h3>SẢN PHẨM LIÊN QUAN</h3>
<div class="row"><br>

	<?php 
	$rand = mt_rand(1,3);
	if ($row['loaihang']=='mubaohiem') {
		$sql1 = "SELECT * FROM product where loaihang ='mubaohiem' LIMIT $rand,6";
	} else if($row['loaihang']=='gangtay'){
		$sql1 = "SELECT * FROM product where loaihang='gangtay' LIMIT $rand,6";

	}else if($row['loaihang']=='giay'){
		$sql1 = "SELECT * FROM product where loaihang='giay' LIMIT $rand,6";

	}else if($row['loaihang']=='giap'){
		$sql1 = "SELECT * FROM product where loaihang='giap' LIMIT $rand,6";

	}else if($row['loaihang']=='balo'){
		$sql1 = "SELECT * FROM product where loaihang='balo' LIMIT $rand,6";

	}else if($row['loaihang']=='combo'){
		$sql1 = "SELECT * FROM product where loaihang='combo' LIMIT $rand,6";

	} else {
		$sql1 = "SELECT * FROM product where loaihang='' LIMIT $rand,6";
	}
	$result1=mysqli_query($conn, $sql1);
	?>

	<div class="container">
		<?php 
		while ($row1=mysqli_fetch_assoc($result1)) {
			echo "<div class='row'>";
			for($i=1;$i<=4;$i++){


				echo "<div class='col-12 col-sm-3 thumbnail'>";
				if ($row1!=false)
				{
					echo "<div class='hover1'>";
					$link = "../image/".$row1['img'];
					echo "<a href='detail.php?id=$row1[id]'><img style='width: 250px; height: 250px' class='card-img-top img-thumbnail rounded image5' src='$link'  >";
					echo "</a>";
					echo"<div class='middle1'>";

					echo"<button type='button' class='btn btn-warning themgiohang' ><a href='cart.php?themgiohang=$row[id]'><img  src='../images/logocard.png'  ></a></button>";
					echo "</div>";
					echo "</div>";
					echo "<div class='card-body'>";
					echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='detail.php?id=$row1[id]'>". $row1['tensp'];
					echo "</a></p>";
					echo "<h5 style='color: red' class='text-center' style='margin-top:-15px;'>". number_format($row1['dongia']).'₫';
					echo "</h5>";
					echo "</div>"; 
				}
				else{
					echo "&nbsp;";
				}
				echo "</div>";

				if($i!=4)
				{
					$row1=mysqli_fetch_array($result1);
				}

			}
			echo "</div>";		
		} ?>	

	</div><br>

</div>
</div>




<?php include("function/footer.php"); ?>