<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../css/style1.css">

<?php 
include('../connect/connect.php');
@session_start();

if (isset($_POST['dathang'])) {
	if (isset($_SESSION['login'])) {
		$sdt = $_SESSION['login'];

		if(isset($_SESSION['cart'])){
			for($i = 0; $i<count($_SESSION['cart']); $i++){
				$query = "SELECT * FROM product where id=".$_SESSION['cart'][$i]['id'];
				$data=mysqli_query($conn, $query);
				$row=mysqli_fetch_array($data);
				
				$tongtiensp = $row['dongia'] * $_SESSION['cart'][$i]['soluong'];
				$id=$_SESSION['cart'][$i]['id'];

				$img = $row['img'];
				$soluong = $_SESSION['cart'][$i]['soluong'];
				$slc = $row['sl'];
				$slb = $_SESSION['cart'][$i]['soluong'];

				if ($slb > $slc ) {
					echo "<script>alert('Sản phẩm không đủ!');</script>";
					header('location: ../function/form.php');
				}
				else{
					$sql = "UPDATE product SET sl = $slc - $slb WHERE id = '$id'";
					$result = mysqli_query($conn, $sql);

					$sql1 = "INSERT INTO sold (stt, idkh, id, soluong, thanhtien, img) VALUES ('','$sdt', '$id', '$soluong', '$tongtiensp','$img')";  	    		
					mysqli_query($conn, $sql1);
				}
				



				
			}

		}
		unset($_SESSION['cart']);
		echo "<script> alert('Mua hàng thành công!'); location.href='../index.php';</script>";
		
	}else{
		header('location: ../login/login.php');
	}
}


?>
<?php include("function/header.php"); ?>

<div class="container" style="padding-top: 120px;">
	<div class="row">
		<div class="col-lg-6">
			<br>
			<h4>CHECKOUT DETAILS</h4><br>
			<?php
			if(isset($c)){ echo $c;}


			?>
		</div>
	</div>
	<div class="row">
		
		<div class="col-sm-12" style="width: 400px; margin-top: 15px; padding: 30px;  border: 1px solid red; background-color: #f2f2f2">
			<div class="row">
				<h5 style="color: #627f9a; margin-left: 20px;">ĐƠN HÀNG CỦA BẠN</h5>
			</div>
			<div class="row">
				<div class="col-sm-8">
					<b>SẢN PHẨM</b>
				</div>
				<div class="col-sm-4">
					<b class="float-right">TỔNG CỘNG</b>
				</div>
				<div class="col-sm-12">
					<hr width="100%" style="border: 1.5px solid #EBEBEB;">
				</div>
			</div>
			<?php 
			if(isset($_SESSION['cart'])){
				for($i = 0; $i<count($_SESSION['cart']); $i++){
					$sql2 = "SELECT * FROM product where id=".$_SESSION['cart'][$i]['id'];
					$data=mysqli_query($conn, $sql2);
					$row=mysqli_fetch_array($data);

					?> 
					<?php 
					$tongtiensp = $row['dongia'] * $_SESSION['cart'][$i]['soluong'];
					?>
					<div class="row">
						<div class="col-sm-4">
							<p><?php echo $row['tensp']; ?> × <?php echo $_SESSION['cart'][$i]['soluong']; ?></p>
						</div>
						<div class="col-sm-4">
							<?php 
							$link = "../image/".$row['img'];
							echo "<a href='$link'><img src='$link' style = 'width: 70px; height: 70px; margin: 0 auto;'></a>";	
							?>
						</div>
						<div class="col-sm-4">
							<p class="float-right"><?php echo number_format($tongtiensp).'₫'; ?></p>
						</div>
					</div><br><br>
				<?php } 
			}
			?>
			<?php 
			$tongtien=0;
			if (isset($_SESSION['cart'])) {
				for($i = 0; $i<count($_SESSION['cart']); $i++){
					$sql3 = "SELECT * FROM product where id=".$_SESSION['cart'][$i]['id'];
					$data=mysqli_query($conn, $sql3);
					$row=mysqli_fetch_array($data);			
					$tongtien = $tongtien + ($row['dongia'] * $_SESSION['cart'][$i]['soluong']);

				}
			}
			?>
			
			<hr width="100%" style="border: 1px solid #EBEBEB; margin-top: -10px;">
			<div class="row">
				<div class="col-sm-8">
					<p><b>TỔNG CỘNG</b></p>
				</div>
				<div class="col-sm-4">
					<p class="float-right"><b><?php echo number_format($tongtien).'₫'; ?></b></p>
				</div>
				<div class="col-sm-12">
					<hr width="100%" style="border: 1.5px solid #EBEBEB; margin-top: -10px;">
				</div>
			</div>
			<div class="row" style="margin-top: 20px;">
				<div class="col-sm-8">
					<p style="color: blue">Trả tiền mặt khi giao hàng.</p>
				</div>
				<div class="col-sm-12">
					<hr width="100%" style="border: 1px solid #EBEBEB; margin-top: -10px;">
				</div>
				<?php
				if(isset($_SESSION['login'])){
					?>
					<form method="POST">
						<button name="dathang" type="submit" class="btn btn-primary" style="margin-left: 20px; margin-top: 30px; width: 100%;">ĐẶT HÀNG</button>
					</form>
					<?php
				}else{
					echo "Đăng nhập để mua hàng: <a href='../login/login.php'> Login?</a>";
				}
				?>
			</div>

		</div>
	</div>
</div>
<br>
<?php include("function/footer.php"); ?>