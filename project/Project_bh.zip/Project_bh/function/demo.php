<form method="POST">
	tensp: <input name="tensp" type="text"><br>
	dongia: <input name="dongia" type="text"><br>
	mota: <input name="mota" type="text"><br>
	img: <input name="img" type="file"><br>
	ngaycn: <input name="ngaycn" type="date"><br>
	sl: <input name="sl" type="text"><br>
	loaihang: <input name="loaihang" type="text"><br>
	search: <input name="search" type="text"><br>
	danhmuc: <input name="danhmuc" type="text"><br>
	hangsx: <input name="hangsx" type="text"><br>
	size: <input name="size" type="text"><br>
	<input name="submit" type="submit">
</form>
<?php 
include('../connect/connect.php');
if (isset($_POST['submit'])) {
	$tensp = $_POST['tensp'];
	$dongia = $_POST['dongia'];
	$mota = $_POST['mota'];
	$img = $_POST['img'];
	$ngaycn = $_POST['ngaycn'];
	$sl = $_POST['sl'];
	$loaihang = $_POST['loaihang'];
	$search = $_POST['search'];
	$danhmuc = $_POST['danhmuc'];
	$hangsx = $_POST['hangsx'];
	$size = $_POST['size'];

	$sql = "INSERT INTO `product`(`id`, `tensp`, `dongia`, `mota`, `img`, `ngaycn`, `sl`, `loaihang`, `search`, `danhmuc`, `hangsx`, `size`) VALUES ('','$tensp','$dongia','$mota','$img','$ngaycn','$sl','$loaihang','$search','$danhmuc','$hangsx','$size')";
	$result = mysqli_query($conn, $sql);

	echo "thành công";
}
 ?>