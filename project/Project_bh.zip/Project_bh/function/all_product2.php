<div style="background: #f8f8f8">
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../css/style1.css">

<?php 
$loaihang=$_GET['loaihang'];
include('../connect/connect.php');
if(isset($_GET['tukhoa'])){
	$query = "SELECT * FROM product where (tensp like '%{$_GET['tukhoa']}%' or loaihang like '%{$_GET['tukhoa']}%') and search = '0' ";
	
} else{
	$query = "SELECT * FROM product LIMIT 33, 32";
}


$data=mysqli_query($conn, $query);


?>	
<?php include("function/header.php"); ?>


<div class="container" style="padding-top: 90px;">
	<div class="row">
		<div class="col-lg-6">
			<br>
			<h4>SẢN PHẨM</h4><br>
		</div>
		<div class="col-lg-6">
			<br>
			<select class="form-control col-sm-6 float-right" >
				<option>Thứ tự mặc định</option>
				<option>Thứ tự theo mức độ phổ biến</option>
				<option>Thứ tự theo điểm đánh giá</option>
				<option>Thứ tự theo sản phẩm mới</option>
				<option>Thứ tự theo giá: thấp đến cao</option>
				<option>Thứ tự theo giá: cao xuống thấp</option>
			</select>
		</div>
	</div>

	<div class="row">
		<div  class="col-sm-2">
			<li style="list-style: none; "><a style="text-decoration: none; font-size: 15px" href="catalog.php?tukhoa=chien+thuat">Balo chiến thuật</a></li><hr>
			<li style="list-style: none; "><a style="text-decoration: none; font-size: 15px" href="catalog.php?tukhoa=4+mon">Combo phượt 4 món</a></li><hr>
			<li style="list-style: none; "><a style="text-decoration: none; font-size: 15px" href="catalog.php?tukhoa=5+mon">Combo phượt 5 món</a></li><hr>
			<li style="list-style: none; "><a style="text-decoration: none; font-size: 15px" href="catalog.php?tukhoa=giay+tnf">Giày TNF</a></li><hr>
			<li style="list-style: none; "><a style="text-decoration: none; font-size: 15px" href="catalog.php?tukhoa=giay+swat">Giày Swat</a></li><hr>
			<li style="list-style: none; "><a style="text-decoration: none; font-size: 15px" href="catalog.php?tukhoa=gxt">Mũ bảo hiểm GXT</a></li><hr>
		</div>
		<div class="col-sm-10">

			<?php 
			while ($row=mysqli_fetch_assoc($data)) {
				echo "<div class='row'>";
				for($i=1;$i<=4;$i++){


					echo "<div class='col-sm-3 thumbnail'>";
					if ($row!=false)
					{
						echo "<div class='hover1'>";
						$link = "../image/".$row['img'];
						echo "<a href='detail.php?id=$row[id]'><img style='width: 250px; height: 250px' class='image5 card-img-top img-thumbnail rounded ' src='$link'  >";
						echo "</a>";
						echo"<div class='middle1'>";
						
						echo"<button type='button' class='btn btn-warning themgiohang' ><a href='cart.php?themgiohang=$row[id]'><img  src='../images/logocard.png'  ></a></button>";
						echo "</div>";
						echo "</div>";
						echo "<div class='card-body'>";
						echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='detail.php?id=$row[id]'>". $row['tensp'];
						echo "</a></p>";
						echo "<h5 class='text-center' style='margin-top:-15px; color:red'>". number_format($row['dongia']).'₫';
						echo "</h5>";
						echo "</div>"; 
					}
					else{
						echo "&nbsp;";
					}
					echo "</div>";

					if($i!=4)
					{
						$row=mysqli_fetch_array($data);
					}

				}
				echo "</div>";		
			} ?>

			<hr class="hr5">
					
					<div style="float: right;" class="chonpage">
						<nav aria-label="Page navigation example">
							 <ul class="pagination">
							    <li class="page-item">
							      	<a class="page-link" href="#" aria-label="Previous">
							        <span aria-hidden="true">&laquo;</span>
							        <span class="sr-only">Previous</span>
							      	</a>
							    </li>
							    <li class="page-item"><a class="page-link" href="all_product.php">1</a></li>
							    <li class="page-item"><a class="page-link" href="all_product2.php">2</a></li>
							    <li class="page-item"><a class="page-link" href="#">3</a></li>
							    <li class="page-item"><a class="page-link" href="#">4</a></li>
							    <li class="page-item"><a class="page-link" href="#">5</a></li>
							    <li class="page-item">
							      	<a class="page-link" href="#" aria-label="Next">
							        <span aria-hidden="true">&raquo;</span>
							        <span class="sr-only">Next</span>
							      	</a>
							    </li>
							</ul>
						</nav>
					</div>
			
		</div>
	</div>	
</div>



<?php include("function/footer.php"); ?>