<div style="background: #f8f8f8">
<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../css/style1.css">
<?php 
include('function/header.php');
?>
<hr>
<div style="margin-top: 140px" class="container">
	<div class="row">
		<div class="col-sm-4">
			<div><img src="../images/info.png" width="290" height="350" /></div>
		</div>
		<div class="col-sm-8">
			<div><font color="red" size="6px"><b>Thông tin người phát triển</b></font></div><br />
			<font size="4px">
				<table class="table table-hover">
					<tbody>
						<tr>
							<td><b style="color: #7c7cde">Đề tài: </b></td>
							<td style="color: #a4a4bf">Web bán hàng</td>
						</tr>
					</tbody>
					<tbody>
						<tr>
							<td><b style="color: #7c7cde">Họ & tên: </b></td>
							<td style="color: #a4a4bf">Phạm Thanh Tươi</td>
						</tr>
					</tbody>
					<tbody>
						<tr>
							<td><b style="color: #7c7cde">Quê Quán:</b></td>
							<td style="color: #a4a4bf">Quảng Nam</td>
						</tr>
					</tbody>
					<tbody>
						<tr>
							<td><b style="color: #7c7cde">Sinh viên:</b></td>
							<td style="color: #a4a4bf">Trường cao đẳng Công nghệ thông tin</td>
						</tr>
					</tbody>
					<tbody>
						<tr>
							<td><b style="color: #7c7cde">Email: </b></td>
							<td style="color: #a4a4bf">171C900045@itf.edu.vn</td>
						</tr>
					</tbody>
					<tbody>
						<tr>
							<td><b style="color: #7c7cde">Facebook: </b></td>
							<td style="color: #a4a4bf"><a style="text-decoration: none;" href="https://www.facebook.com/thanhtuoi.pham.1806">https://www.facebook.com/thanhtuoi.pham.1806</a></td>
						</tr>
					</tbody>
				</table>
			</font>
		</div>
	</div>
</div>
<hr>	
<?php 
include('function/footer.php');
?>