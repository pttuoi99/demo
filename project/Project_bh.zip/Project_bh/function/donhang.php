<?php 
@session_start();
include('../connect/connect.php');

	$id = $_SESSION['login'];
	$sql = "SELECT * FROM `sold` WHERE idkh ='$id'";
	$result = mysqli_query($conn, $sql);

 ?>
 


 <table>
 	<thead>
 		<tr>
 			<th>stt</th>
 			<th>idkh</th>
 			<th>soluong</th>
 			<th>id</th>
 			<th>thanhtien</th>
 			<th>ngaymua</th>
 		</tr>
 	</thead>
 	<?php while ($row = mysqli_fetch_assoc($result)) { ?>
 	<tbody>
 		<tr>
 			<td><?= $row['stt']  ?></td>
 			<td><?= $row['idkh']  ?></td>
 			<td><?= $row['soluong']  ?></td>
 			<td><?= $row['id']  ?></td>
 			<td><?= $row['thanhtien']  ?></td>
 			<td><?= $row['ngaymua']  ?></td>
 		</tr>
 	</tbody>
 </table>
  <?php } ?>