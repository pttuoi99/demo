<div style="background: #f8f8f8">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/style1.css">

	<?php 
	include('../connect/connect.php');
	@session_start();


	if(isset($_SESSION['cart'])){
		if(isset($_GET['trugiohang'])){
			$id = $_GET['trugiohang'];
			for($i=0; $i < count($_SESSION['cart']); $i++){
				if($_SESSION['cart'][$i]['id'] == $id){
					$_SESSION['cart'][$i]['soluong'] = $_SESSION['cart'][$i]['soluong']- 1;
				}elseif ($_SESSION['cart'][$i]['soluong'] == 1) {
					$_SESSION['cart'][$i]['soluong'] = $_SESSION['cart'][$i]['soluong'] - 0;
				}
			}
			header("Location: cart.php");
		}
		if(isset($_GET['conggiohang'])){
			$id = $_GET['conggiohang'];
			for($i=0; $i < count($_SESSION['cart']); $i++){
				if($_SESSION['cart'][$i]['id'] == $id){
					$_SESSION['cart'][$i]['soluong'] = $_SESSION['cart'][$i]['soluong']+ 1;
				}
			}
			header("Location: cart.php");
		}
	}
	if(isset($_SESSION['cart'])){
		if(isset($_GET['xoasanpham'])){
			$id = $_GET['xoasanpham'];
			for($i=0; $i < count($_SESSION['cart']); $i++){
				if($_SESSION['cart'][$i]['id'] == $id){
					unset($_SESSION['cart'][$i]);
					$_SESSION['cart'] = array_values($_SESSION['cart']);
				}
			}	
			header("Location: cart.php");
		}
		
	}

	if(isset($_GET['themgiohang'])){
		$id = $_GET['themgiohang'];
		if(isset($_SESSION['cart']) && is_array($_SESSION['cart'])){
			$count = count($_SESSION['cart']);
			$flag = false;
			for($i = 0; $i<$count; $i++){
				if($_SESSION['cart'][$i]["id"]==$id){
					$_SESSION['cart'][$i]["soluong"]+=1;
					$flag = true;
					break;
				}
			}
			if($flag == false){
				$_SESSION['cart'][$count]['id']=$id;
				$_SESSION['cart'][$count]["soluong"] = 1;
			}
		} else {
			$_SESSION['cart'] = array();
			$_SESSION['cart'][0]["id"] = $id;
			$_SESSION['cart'][0]["soluong"] = 1;
		}
		header("Location: cart.php");
	}
	
	?>

	<?php include("function/header.php"); ?>

	<div class="container" style="padding-top: 122px;">
		<div class="row">
			<div class="col-lg-12">
				<br>
				<h2>CART</h2><br>
			</div>
		</div>	
	</div>
	<?php if ($_SESSION['cart']) { ?>
		<div class="container">
			<div class="row">
				<div class="col-sm-8 cart">
					<table class="text-left">
						<thead style="border-bottom: 3px solid #EBEBEB; ">
							<tr>
								<th >SẢN PHẨM</th>
								<th class="text-center">GIÁ</th>
								<th class="text-center">SỐ LƯỢNG</th>
								<th class="text-center">TỔNG CỘNG</th>
							</tr>
						</thead>
						<tbody>

							<?php 
							if(isset($_SESSION['cart'])){
								for($i = 0; $i<count($_SESSION['cart']); $i++){
									$sql = "SELECT * FROM product where id=".$_SESSION['cart'][$i]['id'];
									$result=mysqli_query($conn, $sql);
									$row=mysqli_fetch_array($result);
									?>

									<?php 
									$tongtiensp = $row['dongia'] * $_SESSION['cart'][$i]['soluong'];
									?>

									<tr style="border-bottom: 1px solid #EBEBEB;">

										<td>
											<?php
											$link = "../image/".$row['img'];

											echo "<a href='detail.php?id=$row[id]'><img style='width: 100px; height: 100px' src='$link'  ></a>"; ?>

											<p ><?php echo $row['tensp']; ?></p>
										</td>

										<td>
											<span><?php echo number_format($row['dongia']).'₫' ?></span>
										</td>
										<td>
											<div style="padding: 15px;">
												<a href="?trugiohang=<?php echo $row['id']; ?>" class="btn btn-info" >-</a>
												<span type="text" class="btn btn-light"><?php echo $_SESSION['cart'][$i]['soluong']; ?>
											</span>
											<a href="?conggiohang=<?php echo $row['id']; ?>" class="btn btn-info" >+</a>
										</div>
									</td>

									<td class="text-center">
										<span><?php echo number_format($tongtiensp).'₫'; ?></span>
									</td>
									<td>
										<a href="?xoasanpham=<?php echo $row['id']; ?>"><button type="button" class="close" aria-label="Close"><span aria-hidden="true"><i class="fa fa-trash"></i></span></button></a>
									</td>
								</tr>
							<?php } 
						}	
						?>

						<tr>
							<td colspan="6"><a href="catalog.php?loaihang=mubaohiem"><button type="button" class="btn btn-success" style="margin-top: 20px;">TIẾP TỤC MUA HÀNG</button></a></td>
						</tr>
					</tbody>
				</table>
			</div>
			<?php 
			$tongtien=0;
			if (isset($_SESSION['cart'])) {
				for($i = 0; $i<count($_SESSION['cart']); $i++){
					$sql = "SELECT * FROM product where id=".$_SESSION['cart'][$i]['id'];
					$result=mysqli_query($conn, $sql);
					$row=mysqli_fetch_array($result);			
					$tongtien = $tongtien + ($row['dongia'] * $_SESSION['cart'][$i]['soluong']);

				}
			}
			?>

			<div class="col-sm-4" style="border-left: 1px solid #EBEBEB; padding-left: 50px;">
				<h4 style="border-bottom: 3px solid #EBEBEB;">TỔNG GIỎ HÀNG</h4>

				<table width="310px">
					<tbody>
						<tr style="border-bottom: 1px solid #EBEBEB;">
							<th>Tổng phụ</th>
							<td class="text-right"><span><?php echo number_format($tongtien).'₫'; ?></span></td>
						</tr>
						<tr style="border-bottom: 3px solid #EBEBEB;">
							<th>Tổng cộng</th>
							<td class="text-right"><span><?php echo number_format($tongtien).'₫'; ?></span></td>
						</tr>
					</tbody>
				</table><br>
				<input type="text" name="" class="" id="" value="" placeholder="Mã giảm giá" style="width: 100%; margin-bottom: 10px; border-radius: 5px;"><br>

				<div style="margin-top: 20px; margin-bottom: 10px;">
					<a href="form.php"><button type="button" class="btn btn-danger" style="width: 100%;">THANH TOÁN</button></a>
				</div>
			</div>
		</div><br><br>
	</div>
<?php }else{
	echo "<p style='margin-top: 20px; padding-left:40%; color: red'>Chưa có sản phẩm nào trong giỏ hàng!</p>";
	echo '
	<tr>
	<td colspan="6"><a href="catalog.php?loaihang=mubaohiem"><button type="button" class="btn btn-success" style="margin-bottom: 20px; margin-left:46%;">MUA HÀNG</button></a></td>
	</tr>
	';
} ?>

<?php include("function/footer.php"); ?>