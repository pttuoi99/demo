		<div class="ft1">
			<div class="container">
				<div class="row ">
					<div class="col-sm-4 ft2">
						<p><b style="color: blue">GIỚI THIỆU</b></p>
						<hr>
						<br>
						<p><b>PHƯỢT BỤI – ĐỒ PHƯỢT GIÁ TỐT</b></p>
						<li style="color: #333130">Đường Nam Kì Khởi Nghĩa - Hòa Quý - Ngũ Hành Sơn - Đà Nẵng.</li>
						<li style="color: #333130">Số 6 ngõ 15 Vương Thừa Vũ - Thanh Xuân - Hà Nội.</li>
						<li style="color: #333130">Hotline: 0975.323.376 (Zalo / FB)</li>
					</div>

					<div class="col-sm-4 ft2">
						<p><b style="color: blue">TỪ KHOÁ TÌM KIẾM</b></p>
						<hr>
						<br>
						<br>
						<p style="color: #333130">Balo chiến thuật, Kính Phượt, Mũ Các Loại, Mũ bảo hiểm GXT, Mũ bảo hiểm Royal,...</p>
					</div>

					<div class="col-sm-4 ft2">
						<p><b style="color: blue">LIÊN HỆ</b></p>
						<hr>
						<br>
						<span style="color: #333130">Gọi mua hàng: </span><a href="#" style="text-decoration: none;">1800.1066 </a><span style="color: #333130">(7:30 - 22:00)</span> <br>
						<span style="color: #333130">Gọi khiếu nại: </span><a href="#" style="text-decoration: none;">1800.1068 </a><span style="color: #333130">(8:00 - 21:00)</span> <br>
						<span style="color: #333130">Gọi bảo hành: </span><a href="#" style="text-decoration: none;">1800.1063 </a><span style="color: #333130">(8:00 - 21:00)</span><br>
						<span style="color: #333130">Hỗ trợ kỹ thuật: </span><a href="#" style="text-decoration: none;">1800.1065 </a><span style="color: #333130">(17:30 - 21:00)</span> <br>
						<a href=""><img src="../images/tb.png" /></a>

					</div>
				</div>
				<div class="container">
					<div class="row">
						<div class="col-10 col-md-12">
							<p class="ft3">Copyright 2019 &copy; By <a href="info.php">ThanhTươi Phạm</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>

		