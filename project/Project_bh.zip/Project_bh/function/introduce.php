<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../css/style1.css">
<?php 
include('function/header.php');
?>

<div style="margin-top: 115px;" class="container-fluid bg-light">
	<div class="row">
		<img style="margin: 1% 0 0 5%; width: 50%; height: 200px" src="../images/introduce.jpg" >
		<div style="margin: 1% 0 0 5%" class="col-12 col-sm-10">
			<h2>PHƯỢT BỤI STORE – ĐỒ PHƯỢT GIÁ TỐT</h2>
			<li>Cửa hàng chuyển cung cấp các mặt hàng đồ phượt,đồ du lịch,đồ bảo hộ xe máy với hơn 5 năm kinh nghiệm trên thị trường shop Phượt Bụi Store luôn là sự lựa chọn hàng đầu đối với các phượt thủ chuyên nghiệp.</li>
			<li>Cửa hàng bán buôn bán lẻ hơn 100 mặt hàng khác nhau, phân phối bán buôn bán lẻ toàn quốc uy tín và trách nhiệm.
			</li>
			<li>Địa chỉ: Đường Nam Kì Khởi Nghĩa - Hòa Quý - Ngũ Hành Sơn - Đà Nẵng.</li>
			<li>Hotline: 0975323376 – 0919918817</li>
		</div>
		<div style="margin: 1% 0 0 5%" class="col-12 col-sm-8">
			<div>
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4561.544618653691!2d108.25098953106779!3d15.972521094254814!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x88fc9cdcb6d63f85!2zVHLGsOG7nW5nIENhbyDEkeG6s25nIEPDtG5nIG5naOG7hyBUaMO0bmcgdGluIC0gxJDhuqFpIGjhu41jIMSQw6AgTuG6tW5n!5e0!3m2!1svi!2s!4v1553869027835!5m2!1svi!2s" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
		</div>
	</div>
</div>
<hr>	
<?php 
	include('function/footer.php');
 ?>