<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../css/style1.css">

<style>
	body {font-family: Arial, Helvetica, sans-serif;}

	/* Full-width input fields */
	input[type=text], input[type=password] {
		width: 100%;
		padding: 5px 10px;
		margin: 8px 0;
		display: inline-block;
		border: 3px solid #ccc;
		box-sizing: border-box;
	}

	/* Set a style for all buttons */
	button {
		background-color: #4CAF50;
		color: white;
		padding: 10px 20px;
		margin: 8px 0;
		border: none;
		cursor: pointer;
		width: 100%;
		opacity: 0.5;
	}
	button:hover{
		opacity: 1;
	}

	

	/* Extra styles for the cancel button */
	.cancelbtn {
		width: auto;
		padding: 10px 18px;
		background-color: #f44336;
	}

	/* Center the image and position the close button */
	.imgcontainer {
		text-align: center;
		margin: 24px 0 12px 0;
		position: relative;
	}

	.container {
		padding: 16px;
	}

	span.psw {
		float: right;
		padding-top: 16px;
	}

	/* The Modal (background) */
	.modal {
		display: none; /* Hidden by default */
		position: fixed; /* Stay in place */
		z-index: 1; /* Sit on top */
		left: 0;
		top: 0;
		width: 40%; /* Full width */
		height: 40%; /* Full height */
		overflow: auto; /* Enable scroll if needed */
		background-color: rgb(0,0,0); /* Fallback color */
		background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
		padding-top: 60px;
	}

	/* Modal Content/Box */
	.modal-content {
		background-color: #fefefe;
		margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
		border: 1px solid #888;
		width: 100px; /* Could be more or less, depending on screen size */
	}

	/* The Close Button (x) */
	.close {
		position: absolute;
		right: 25px;
		top: 0;
		color: #000;
		font-size: 35px;
		font-weight: bold;
	}

	.close:hover,
	.close:focus {
		color: red;
		cursor: pointer;
	}

	/* Add Zoom Animation */
	.animate {
		-webkit-animation: animatezoom 0.6s;
		animation: animatezoom 0.6s;
		bottom: 50px;
	}

	@-webkit-keyframes animatezoom {
		from {-webkit-transform: scale(0)} 
		to {-webkit-transform: scale(1)}
	}

	@keyframes animatezoom {
		from {transform: scale(0)} 
		to {transform: scale(1)}
	}

	/* Change styles for span and cancel button on extra small screens */
	@media screen and (max-width: 300px) {
		span.psw {
			display: block;
			float: none;
		}
		.cancelbtn {
			width: 100%;
		}
	}
</style>
<style>
	.input{
		background-color: blue;
		color: white;
		cursor: pointer;
		opacity: 0.5;
	}
	.input:hover{
		opacity: 1;
	}
</style>
<?php include('login/header.php') ?>
<?php 
include('../connect/connect.php');
@session_start();
if (isset($_SESSION['login'])) {
	$idkh = $_SESSION['login'];
	$sql = "SELECT * FROM customer WHERE sdt = $idkh ";	
	$result = mysqli_query($conn, $sql);

}
?>

<div class="container-fluid" style="margin-top: 100px;">
	<div class="row">
		<div style="margin: 0 auto;" class="col-md-8 col-md-offset-3">
			<?php while ($row = mysqli_fetch_assoc($result)) { ?>


				<table border="1px"  style="width: 80%; font-size: 20px; margin: 0 auto">
					<tr>
						<th>Họ & tên</th>
						<td><?php echo $row['hoten']; ?></td>
					</tr>
					<tr>
						<th>Email</th>
						<td><?php echo $row['email']; ?></td>
					</tr>
					<tr>
						<th>Số điện thoại</th>
						<td><?php echo $row['sdt']; ?></td>
					</tr>
					<tr>
						<th>Địa chỉ</th>
						<td><?php echo $row['diachi']; ?></td>
					</tr>
					<tr>
						<th>Tỉnh(thành phố)</th>
						<td><?php echo $row['tp']; ?></td>
					</tr>
				</table>
			<?php } ?>
		</div>
	</div>

	<?php 
	if (isset($_POST['login'])) {
		$old_pass = $_POST['old_pass'];
		$new_pass = $_POST['new_pass'];
		$rety_pass = $_POST['rety_pass'];

		$sql = "SELECT * FROM customer WHERE sdt =".$_SESSION['login'];
		$result = mysqli_query($conn, $sql);	

		$idkh = $_SESSION['login'];

		while ($row = mysqli_fetch_assoc($result)) {
			$pass = $row['password'];
		}
		if ($old_pass == $pass) {
			if ($new_pass == $rety_pass) {
				$sql1 = "UPDATE `customer` SET `password`= '$new_pass' WHERE sdt = '$idkh' ";
				$result = mysqli_query($conn, $sql1);
				if ($result) {
					echo "<script>alert('Đổi mật khẩu thành công!');</script>";
				}else{
					echo "<script>alert('Đổi mật khẩu không thành công!');</script>";
				}
			}else{
				echo "<script>alert('Mật khẩu nhập lại không đúng!');</script>";
			}
		}else{
			echo "<script>alert('Mật khẩu cũ không đúng!');</script>";
		}			
	}
	?>

	<div style="padding-top: 50px;" class="row">
		<div style="margin: 0 auto;" >
			<script>
				$(document).ready(function(){
					$('.dangxuat').click(function(){
						if (confirm('Bạn có muốn đăng xuất tài khoản không?')) {

						}else{
							return false;
						}
						
					})
				})
			</script>
			<!-- nút đăng xuất -->
			<a class="dangxuat" href="../login/logout.php"><input class="input" type="submit" value="Đăng Xuất"></a>
			<!-- nút đổi mật khẩu -->
			<input class="input" type="submit" onclick="document.getElementById('id01').style.display='block'" style="width:auto;" value="Đổi mật khẩu">

			<div id="id01" class="modal">

				<form method="POST" style="width: 40%" class="modal-content animate">
					<div class="imgcontainer">
						<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
					</div>

					<div class="container">
						<?php echo "<b>Tài khoản </b>".$_SESSION['login']; ?><br>
						<label for="old_pass"><b>old password</b></label>
						<input type="password" placeholder="Mật khẩu cũ" id="old_pass" name="old_pass" required>

						<label for="new_pass"><b>new password</b></label>
						<input type="password" placeholder="Mật khẩu mới" id="new_pass" name="new_pass" required id="psw" name="psw" title="Phải chứa ít nhất 8 ký tự trở lên" pattern=".{8,}">

						<label for="rety_pass"><b>repeat password</b></label>
						<input type="password" placeholder="Nhập lại mật khẩu" id="rety_pass" name="rety_pass" required>
						<hr>

						<button name="login" type="submit">Login</button>
					</div>

					<div class="container" style="background-color:#f1f1f1">
						<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
						<span class="psw">Forgot <a href="#">password?</a></span>
					</div>
				</form>
			</div>
			<script>
				// Get the modal
				var modal = document.getElementById('id01');

				// When the user clicks anywhere outside of the modal, close it
				window.onclick = function(event) {
					if (event.target == modal) {
						modal.style.display = "none";
					}
				}
			</script>
			<!-- nut xem đơn hàng -->
			<input class="input" type="submit" onclick="document.getElementById('id02').style.display='block'" style="width:auto;" value="Đơn hàng đã đặt">

			<div id="id02" class="modal">

				<form method="POST" style="width: 70%" class="modal-content animate">
					<div class="imgcontainer">
						<span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
					</div>

					<div class="container">

						<h3 align="center">DANH SÁCH ĐƠN HÀNG</h3>
						<div style="margin: 0 auto;" class="col-md-10 col-md-offset-3">
							<table class="table table-hover">
								<thead>
									<tr>
										<th>sản phẩm</th>
										<th>Số lượng</th>
										<th>Thành tiền</th>
										<th>Ngày mua</th>
									</tr>
								</thead>

								<tbody class="danhsach">
									<?php 
									include('../connect/connect.php');
									$sql2 = "SELECT * FROM sold WHERE idkh=".$_SESSION['login'];
									$query2 = mysqli_query($conn, $sql2);
									$num = mysqli_num_rows($query2);
									if ($num > 0 ) {
										while ($row = mysqli_fetch_array($query2)) {

											?>
											<tr>
												<?php $link = "../image/".$row['img']; ?>
												<td><?php echo "<img style='width: 50px; ' src='$link'>" ?></td>
												<td><?php echo $row['soluong'] ?></td>
												<td><?php echo $row['thanhtien'] ?></td>
												<td><?php echo $row['ngaymua'] ?></td>
											</tr>
											<?php
										}
									}else{
										echo "Xin chào ".$_SESSION['login'].". Bạn chưa đặt một đơn hàng nào cả!";
									}
									?>
								</tbody>

							</table>
						</div>
					</div>
				</form>
			</div>
			<script>
				// Get the modal
				var modal = document.getElementById('id02');

				// When the user clicks anywhere outside of the modal, close it
				window.onclick = function(event) {
					if (event.target == modal) {
						modal.style.display = "none";
					}
				}
			</script>

			<script>
				function openForm() {
					document.getElementById("myForm").style.display = "block";
				}

				function closeForm() {
					document.getElementById("myForm").style.display = "none";
				}
			</script>


			<script>
				var myInput = document.getElementById("psw");
				var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
	document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
	document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {  
  // Validate length
  if(myInput.value.length >= 8) {
  	length.classList.remove("invalid");
  	length.classList.add("valid");
  } else {
  	length.classList.remove("valid");
  	length.classList.add("invalid");
  }
}
</script>


</div>
</div>
</div>

<div style="margin-top: 50px;">
	<?php include('login/footer.php') ?>
</div>