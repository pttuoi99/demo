<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../css/style1.css">

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <style>
    .form {
      background-color: #f2f2f2;
      padding: 5px 20px 15px 20px;
      border: 1px solid lightgrey;
      border-radius: 3px;
      width: 50%;
      margin: 0 auto;
      margin-top: 100px;
      margin-bottom: 50px;
    }
    .avt{
      border-radius: 50%;
      width: 16%;
      margin-left: 42%; 
    }
    .button{
      width: 100%;
      color: white;
      background-color: #4caf50;
      border: 1px solid #dad6d6;
      height: 6%;
      border-radius: 1%;
    }
    .button:hover{
      background-color: #72d876;
    }

  </style>
</head>
<body>
  <?php include('login/header.php') ?>
  <?php 
  session_start();
  include('../connect/connect.php');  
  if(isset($_POST['sign'])){
  
    
      $hoten=$_POST['hoten'];
      $email=$_POST['email'];
      $phone=$_POST['phone'];
      $place=$_POST['place'];
      $thanhpho=$_POST['thanhpho'];
      $pass=$_POST['pass'];
      $repass=$_POST['repass'];
    
    if($pass == $repass){
      $sql = "SELECT * FROM customer WHERE sdt='$phone'";
      $query = mysqli_query($conn, $sql);
      $num = mysqli_num_rows($query);
      if($num == 0){
        $sql = "INSERT INTO `customer`(`idkh`, `hoten`, `email`, `sdt`, `diachi`, `tp`,`password`) VALUES('','$hoten','$email','$phone','$place','$thanhpho','$pass')";
        $result = mysqli_query($conn,$sql);
        if($result){
          // echo "<p style='color: blue; margin-top: 80px;'>Đăng ký thành công!</p>";
          echo "<script>alert('Đăng kí thành công!')</script>";
        }else{
          // echo "<p style='color: red'; margin-top: 80px;>Đăng ký không thành công!</p>";
          echo "<script>alert('Đăng kí không thành công!')</script>";
        }
      }else{
        // echo "<p style='color: red'; margin-top: 80px;>Số điện thoại này đã có tài khoản!</p>";
        echo "<script>alert('Số điện thoại này đã có tài khoản')</script>";
      }
    }else{
      echo "<p style='color: red; margin-top: 50px;'>Password và Repeat password không trùng nhau!</p>";
    }}
  
  ?>
  <div class="form">  
   <h1>Sign Up</h1>
   <span>Please fill in this form to create an account.</span>
   <span style="float: right;">You already have an account: <a href="login.php">Login?</a></span>
   <hr>
   <div class="container">
    <form method="POST">
      <div class="row">
        <div class="form-group col-sm-12">
          <label for="hoten"><b><i class="fa fa-user icon"></i> Full name</b></label>
          <input type="text" class="form-control" id="hoten" name="hoten" placeholder="Họ & tên" required>
        </div>
        <div class="form-group col-sm-6">
          <label for="email"><b><i class="fa fa-envelope icon"></i> Email</b></label>
          <input type="email" class="form-control" id="email" name="email" placeholder="example@gmail.com" required>
        </div>
        <div class="form-group col-sm-6">
          <label for="phone"><b><i class="fa fa-phone icon"></i> Phone</b></label>
          <input type="number" class="form-control" id="phone" name="phone" placeholder="0123456789" required>
        </div>
        <div class="form-group col-sm-6">
          <label for="place"><b><i class="fa fa-address icon"></i> Địa chỉ</b></label>
          <input type="address" class="form-control" id="place" name="place" placeholder="Số 5, đường văn,..." required>
        </div>
        <div class="form-group col-sm-6">
          <label for="thanhpho"><b><i class="fa fa-institution icon"></i> Tỉnh(Thành phố)</b></label>
          <input type="text" class="form-control" id="thanhpho" name="thanhpho" placeholder="Hồ Chí Minh" required>
        </div>
        <div class="form-group col-sm-6">
          <label for="pass"><b><i class="fa fa-key icon"></i> Password</b></label>
          <input type="password" class="form-control" id="pass" name="pass" placeholder="Enter password" required id="psw" name="psw" title="Phải chứa ít nhất 8 ký tự trở lên" pattern=".{8,}">
        </div>
        <div class="form-group col-sm-6">
          <label for="repass"><b><i class="fa fa-key icon"></i> Repeat password</b></label>
          <input type="password" class="form-control" id="repass" name="repass" placeholder="Enter repeat password" required id="psw">
        </div>
      </div>
      <hr>
      <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>
      <button name="sign" class="button" type="submit">Sign Up</button>
    </form>
    <br>

    <div class="container" style="background-color:#f1f1f1">

    </div>
  </div>
</div>
<script>
  var myInput = document.getElementById("psw");
  var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
</body>
</html>
<?php include('login/footer.php') ?>