<link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../css/style1.css">


<?php 
include('../connect/connect.php');
session_start();
$sdt = isset($_POST['sdt']) ? $_POST['sdt'] : '';
$pw = isset($_POST['pass']) ? $_POST['pass'] : '';
if (isset($_SESSION['login'])) {
  header('location: ../login/ttkh.php');
}else{
  if(isset($_POST['submit'])){
    $sql = "SELECT * FROM customer where sdt='$sdt' and password='$pw'";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result)){
      $_SESSION['login'] = $sdt;
      $_SESSION['password'] = $pw;
      header("Location: ../function/form.php");
    }
    else{
      echo "<p style='margin-top: 50px; color: red;'> Username hoặc Password không đúng!</p>";
    }
  }

  ?>
  <!DOCTYPE html>
  <html>
  <head>
    <title></title>
    <style>
      .form {
        background-color: #f2f2f2;
        padding: 5px 20px 15px 20px;
        border: 1px solid lightgrey;
        border-radius: 3px;
        width: 40%;
        margin: 0 auto;
        margin-top: 100px;
        margin-bottom: 50px;
      }
      .avt{
        border-radius: 50%;
        width: 16%;
        margin-left: 42%; 
      }
      .btn{
        width: 100%;
        color: #4CAF50;
      }
    </style>
  </head>
  <body>
    <?php include('login/header.php') ?>

    <div class="form">  
      <h2>Login Form</h2>
      <img src="../Images/login.png" alt="Avatar" class="avt">
      <div class="container">
        <form method="POST">
          <div class="form-group">
            <label for="sdt"><b><i class="fa fa-phone icon"> Số điện thoại</i></b></label>
            <input name="sdt" type="text" class="form-control" id="sdt"  placeholder="0123456789" required="Vui lòng nhập Username">
          </div>
          <div class="form-group">
            <label for="password"><b><i class="fa fa-key icon"> Password</i></b></label>
            <input name="pass" type="password" class="form-control" id="password" placeholder="Password" required="Vui lòng nhập Password">
          </div>
          <label>
            <input type="checkbox" checked="checked" name="remember"> Remember me
          </label>
          <hr>
          <button name="submit" type="submit" class="btn btn-primary">Login</button>
        </form>
        <br>
        <div class="container" style="background-color:#f1f1f1">
          <span>No account. <a href="Signup.php">Sign in?</a></span>
          <span style="float: right;">Forgot <a href="#">password?</a></span>
        </div>
      </div>
    </div>
  </body>
  </html>
  <?php include('login/footer.php') ?>
<?php } ?>