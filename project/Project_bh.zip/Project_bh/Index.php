<div style="background: #f8f8f8">
	<?php 
include('connect/connect.php');
$tukhoa=$_GET['tukhoa'];
if(isset($_GET['tukhoa'])){
	header('location: function/catalog.php?tukhoa='.$tukhoa);
	
}else{
	
$sql = "SELECT * FROM product where loaihang='mubaohiem' LIMIT 6";
$sql1 = "SELECT * FROM product where loaihang='gangtay' LIMIT 6";
$sql2 = "SELECT * FROM product where loaihang='giay'";
$sql3 = "SELECT * FROM product where loaihang='giap'";
$sql4 = "SELECT * FROM product where loaihang='balo'";
$sql5 = "SELECT * FROM product where loaihang='combo'";
$sql6 = 'SELECT * FROM `product` order by `ngaycn` desc  LIMIT 4';
$result=mysqli_query($conn, $sql);
$result1=mysqli_query($conn, $sql1);
$result2=mysqli_query($conn, $sql2);
$result3=mysqli_query($conn, $sql3);
$result4=mysqli_query($conn, $sql4);
$result5=mysqli_query($conn, $sql5);
$result6 = mysqli_query($conn,$sql6);}
?>	
<link rel="stylesheet" href="css/style1.css">
<link rel="stylesheet" href="css/style.css">
<?php include("home/header.php"); ?>
<div style="padding-top: 66px;">
	<?php include("home/slide.php"); ?>
</div>

<div class="container">
	<p class="float-lg-left tieude"><b>MŨ BẢO HIỂM</b> </p>
</div><hr class="hr1"><br>

<div class="container">
	<?php 
	while ($row=mysqli_fetch_assoc($result)) {
		echo "<div class='row'>";
		for($i=1;$i<=4;$i++){


			echo "<div class='col-sm-3'>";

			if ($row!=false)
			{
				echo "<div class='hover1'>";
				$link2 = "image/".$row['img'];
				echo "<a href='function/detail.php?id=$row[id]'><img class='card-img-top img-thumbnail rounded image5' src='$link2'>";
				echo "</a>";
				echo"<div class='middle1'>";

				echo"<button type='button' class='btn btn-warning themgiohang' ><a href='function/cart.php?themgiohang=$row[id]'><img  src='images/logocard.png'  ></a></button>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card-body'>";
				echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='function/detail.php?id=$row[id]'>". $row['tensp'];
				echo "</a></p>";
				echo "</hr>";

				echo "<h5 class='text-right' style='margin-top:-15px; color:red'>". number_format($row['dongia']).'₫';
				echo "</h5>";
				echo "</div>"; 
			}
			else{
				echo "&nbsp;";
			}
			echo "</div>";
			if($i!=4)
			{
				$row=mysqli_fetch_array($result);
			}
		}
		echo "</div>";		
	} ?>	
</div>


<div class="container">
	<p class="float-lg-left tieude"><b>GĂNG TAY</b> </p>
</div><hr class="hr1"><br>

<div class="container">
	<?php 
	while ($row=mysqli_fetch_assoc($result1)) {
		echo "<div class='row'>";
		for($i=1;$i<=4;$i++){


			echo "<div class='col-sm-3'>";

			if ($row!=false)
			{
				echo "<div class='hover1'>";
				$link2 = "image/".$row['img'];
				echo "<a href='function/detail.php?id=$row[id]'><img class='card-img-top img-thumbnail rounded image5' src='$link2'>";
				echo "</a>";
				echo"<div class='middle1'>";

				echo"<button type='button' class='btn btn-warning themgiohang' ><a href='function/cart.php?themgiohang=$row[id]'><img  src='images/logocard.png'  ></a></button>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card-body'>";
				echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='function/detail.php?id=$row[id]'>". $row['tensp'];
				echo "</a></p>";
				echo "</hr>";

				echo "<h5 class='text-right' style='margin-top:-15px; color:red'>". number_format($row['dongia']).'₫';
				echo "</h5>";
				echo "</div>"; 
			}
			else{
				echo "&nbsp;";
			}
			echo "</div>";
			if($i!=4)
			{
				$row=mysqli_fetch_array($result1);
			}
		}
		echo "</div>";		
	} ?>	
</div>



<div class="container">
	<p class="float-lg-left tieude"><b>GIÀY</b> </p>
</div><hr class="hr1"><br>

<div class="container">
	<?php 
	while ($row=mysqli_fetch_assoc($result2)) {
		echo "<div class='row'>";
		for($i=1;$i<=4;$i++){


			echo "<div class='col-sm-3'>";

			if ($row!=false)
			{
				echo "<div class='hover1'>";
				$link2 = "image/".$row['img'];
				echo "<a href='function/detail.php?id=$row[id]'><img style='width: 250px; height: 250px' class='card-img-top img-thumbnail rounded image5' src='$link2'>";
				echo "</a>";
				echo"<div class='middle1'>";

				echo"<button type='button' class='btn btn-warning themgiohang' ><a href='function/cart.php?themgiohang=$row[id]'><img  src='images/logocard.png'  ></a></button>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card-body'>";
				echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='function/detail.php?id=$row[id]'>". $row['tensp'];
				echo "</a></p>";
				echo "</hr>";

				echo "<h5 class='text-right' style='margin-top:-15px; color:red'>". number_format($row['dongia']).'₫';
				echo "</h5>";
				echo "</div>"; 
			}
			else{
				echo "&nbsp;";
			}
			echo "</div>";
			if($i!=4)
			{
				$row=mysqli_fetch_array($result2);
			}
		}
		echo "</div>";		
	} ?>	
</div>



<div class="container">
	<p class="float-lg-left tieude"><b>GIÁP BẢO HỘ</b> </p>
</div><hr class="hr1"><br>

<div class="container">
	<?php 
	while ($row=mysqli_fetch_assoc($result3)) {
		echo "<div class='row'>";
		for($i=1;$i<=4;$i++){


			echo "<div class='col-sm-3'>";

			if ($row!=false)
			{
				echo "<div class='hover1'>";
				$link2 = "image/".$row['img'];
				echo "<a href='function/detail.php?id=$row[id]'><img style='width: 250px; height: 250px' class='card-img-top img-thumbnail rounded image5' src='$link2'>";
				echo "</a>";
				echo"<div class='middle1'>";

				echo"<button type='button' class='btn btn-warning themgiohang' ><a href='function/cart.php?themgiohang=$row[id]'><img  src='images/logocard.png'  ></a></button>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card-body'>";
				echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='function/detail.php?id=$row[id]'>". $row['tensp'];
				echo "</a></p>";
				echo "</hr>";

				echo "<h5 class='text-right' style='margin-top:-15px; color:red'>". number_format($row['dongia']).'₫';
				echo "</h5>";
				echo "</div>"; 
			}
			else{
				echo "&nbsp;";
			}
			echo "</div>";
			if($i!=4)
			{
				$row=mysqli_fetch_array($result3);
			}
		}
		echo "</div>";		
	} ?>	
</div>



<div class="container">
	<p class="float-lg-left tieude"><b>BALO</b> </p>
</div><hr class="hr1"><br>

<div class="container">
	<?php 
	while ($row=mysqli_fetch_assoc($result4)) {
		echo "<div class='row'>";
		for($i=1;$i<=4;$i++){


			echo "<div class='col-sm-3'>";

			if ($row!=false)
			{
				echo "<div class='hover1'>";
				$link2 = "image/".$row['img'];
				echo "<a href='function/detail.php?id=$row[id]'><img class='card-img-top img-thumbnail rounded image5' style='width: 250px; height: 250px' src='$link2'>";
				echo "</a>";
				echo"<div class='middle1'>";

				echo"<button type='button' class='btn btn-warning themgiohang' ><a href='function/cart.php?themgiohang=$row[id]'><img  src='images/logocard.png'  ></a></button>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card-body'>";
				echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='function/detail.php?id=$row[id]'>". $row['tensp'];
				echo "</a></p>";
				echo "</hr>";

				echo "<h5 class='text-right' style='margin-top:-15px; color:red'>". number_format($row['dongia']).'₫';
				echo "</h5>";
				echo "</div>"; 
			}
			else{
				echo "&nbsp;";
			}
			echo "</div>";
			if($i!=4)
			{
				$row=mysqli_fetch_array($result4);
			}
		}
		echo "</div>";		
	} ?>	
</div>



<div class="container">
	<p class="float-lg-left tieude"><b>COMBO PHƯỢT</b> </p>
</div><hr class="hr1"><br>

<div class="container">
	<?php 
	while ($row=mysqli_fetch_assoc($result5)) {
		echo "<div class='row'>";
		for($i=1;$i<=4;$i++){


			echo "<div class='col-sm-3'>";

			if ($row!=false)
			{
				echo "<div class='hover1'>";
				$link2 = "image/".$row['img'];
				echo "<a href='function/detail.php?id=$row[id]'><img style='width: 250px; height: 250px' class='image5 card-img-top img-thumbnail rounded' src='$link2'>";
				echo "</a>";
				echo"<div class='middle1'>";

				echo"<button type='button' class='btn btn-warning themgiohang' ><a href='function/cart.php?themgiohang=$row[id]'><img  src='images/logocard.png'  ></a></button>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card-body'>";
				echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='function/detail.php?id=$row[id]'>". $row['tensp'];
				echo "</a></p>";
				echo "</hr>";

				echo "<h5 class='text-right' style='margin-top:-15px; color:red'>". number_format($row['dongia']).'₫';
				echo "</h5>";
				echo "</div>"; 
			}
			else{
				echo "&nbsp;";
			}
			echo "</div>";
			if($i!=4)
			{
				$row=mysqli_fetch_array($result5);
			}
		}
		echo "</div>";		
	} ?>	
</div>




<div class="container">
	<p class="float-lg-left tieude"><b>SẢN PHẨM MỚI</b> </p>
</div><hr class="hr1"><br>

<div class="container">
	<?php 
	while ($row=mysqli_fetch_assoc($result6)) {
		echo "<div class='row'>";
		for($i=1;$i<=4;$i++){


			echo "<div class='col-sm-3'>";

			if ($row!=false)
			{
				echo "<div class='hover1'>";
				$link2 = "image/".$row['img'];
				echo "<a href='function/detail.php?id=$row[id]'><img style='width: 250px; height: 250px' class='card-img-top img-thumbnail rounded image5' src='$link2'>";
				echo "</a>";
				echo"<div class='middle1'>";

				echo"<button type='button' class='btn btn-warning themgiohang' ><a href='function/cart.php?themgiohang=$row[id]'><img  src='images/logocard.png'  ></a></button>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card-body'>";
				echo "<p class='card-text text-center' style='margin-top:-15px;'><a class='a2' href='function/detail.php?id=$row[id]'>". $row['tensp'];
				echo "</a></p>";
				echo "</hr>";

				echo "<h5 class='text-right' style='margin-top:-15px; color:red'>". number_format($row['dongia']).'₫';
				echo "</h5>";
				echo "</div>"; 
			}
			else{
				echo "&nbsp;";
			}
			echo "</div>";
			if($i!=4)
			{
				$row=mysqli_fetch_array($result6);
			}
		}
		echo "</div>";		
	} ?>
</div>
<?php include("home/footer.php"); ?>
</div>


